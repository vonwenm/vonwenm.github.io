dbyll
=====

2 column stylish theme for jekyll-boostrap-3

INSTALL
=======

Inside jekyll-bootstrap root directory, just run
<pre>
<code>
$ rake theme:install git="https://github.com/jekyll-bs3/dbyll"
</code>
</pre>

**New to Jekyll?**  
Visit [Jekyll-Bootstrap-3](http://ismaildemirbilek.com/jekyll-bootstrap-3/) for more info.
  
LICENSE
=======
[MIT](http://opensource.org/licenses/MIT)