dbyll
=====

2 column stylish theme for jekyll-boostrap-3. Port of original [dbyll theme for Jekyll](http://github.com/dbtek/dbyll).

Install
=======

Inside jekyll-bootstrap root directory, just run
<pre>
<code>
$ rake theme:install git="https://github.com/jekyll-bs3/dbyll"
</code>
</pre>

**New to Jekyll?**  
Visit [Jekyll Bootstrap 3](http://github.com/dbtek/jekyll-bootstrap-3/) for more info.
  
License
=======
[MIT](http://opensource.org/licenses/MIT)

Author
======
İsmail Demirbilek - [@dbtek](http://twitter.com/dbtek)
